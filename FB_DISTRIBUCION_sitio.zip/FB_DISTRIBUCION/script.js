document.getElementById("year").textContent = new Date().getFullYear();

const form = document.getElementById("help-form");
form.addEventListener("submit", (event) => {
  event.preventDefault();
  const data = new FormData(form);
  const subject = encodeURIComponent("Consulta desde FB DISTRIBUCION");
  const body = encodeURIComponent(
    `Nombre: ${data.get("name")}\nCorreo: ${data.get("email")}\nServicio: ${data.get("service")}\n\nConsulta:\n${data.get("message")}`
  );
  // Reemplazá contacto@tudominio.com por tu dirección real antes de publicar.
  window.location.href = `mailto:contacto@tudominio.com?subject=${subject}&body=${body}`;
});
